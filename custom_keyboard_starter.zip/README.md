CustomKeyboardStarter
---------------------
This is a minimal starter Android project for a custom IME (keyboard).
Files included:
- app/src/main/... : Java source, manifest, resources, assets
How to use:
1) Unzip and open this folder in Android Studio.
2) Let Gradle sync and install required SDK components if prompted.
3) Build & run on a device (emulator may need input method enabling).
Notes:
- You may need to enable "Display over apps" permission for floating mode.
- This is a starter skeleton. Implement missing TODOs (storage, settings UI, themes).
