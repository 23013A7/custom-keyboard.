package com.example.customkeyboard.ime;

import android.inputmethodservice.InputMethodService;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputConnection;
import com.example.customkeyboard.views.DynamicKeyboardView;
import com.example.customkeyboard.layouts.LayoutManager;
import com.example.customkeyboard.layouts.KeyboardLayout;

public class MyKeyboardService extends InputMethodService
        implements DynamicKeyboardView.KeyPressListener {

    private DynamicKeyboardView keyboardView;
    private LayoutManager layoutManager;

    @Override
    public void onCreate() {
        super.onCreate();
        layoutManager = new LayoutManager(getApplicationContext());
    }

    @Override
    public View onCreateInputView() {
        LayoutInflater inflater = getLayoutInflater();
        View root = inflater.inflate(com.example.customkeyboard.R.layout.keyboard_view, null);
        keyboardView = root.findViewById(com.example.customkeyboard.R.id.dynamicKeyboard);
        keyboardView.setKeyPressListener(this);

        KeyboardLayout layout = layoutManager.getDefaultLayout();
        keyboardView.bindLayout(layout);
        return root;
    }

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        keyboardView.invalidate();
    }

    @Override
    public void onKeyPressed(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (key) {
            case "⌫":
                ic.deleteSurroundingText(1, 0);
                break;
            case "↵":
                ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER));
                break;
            default:
                ic.commitText(key, 1);
        }
    }

    public void enterFloatingMode() {
        keyboardView.showAsFloating();
    }
}
