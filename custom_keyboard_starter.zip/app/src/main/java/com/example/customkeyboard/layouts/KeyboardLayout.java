package com.example.customkeyboard.layouts;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class KeyboardLayout {
    public String id;
    public String name;
    public List<List<String>> rows = new ArrayList<>();

    public static KeyboardLayout fromJson(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        KeyboardLayout kl = new KeyboardLayout();
        kl.id = o.optString("id", "layout_");
        kl.name = o.optString("name", "Custom");
        JSONArray r = o.getJSONArray("rows");
        for (int i = 0; i < r.length(); i++) {
            JSONArray row = r.getJSONArray(i);
            List<String> rowList = new ArrayList<>();
            for (int j = 0; j < row.length(); j++) rowList.add(row.getString(j));
            kl.rows.add(rowList);
        }
        return kl;
    }
}
