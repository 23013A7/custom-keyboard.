package com.example.customkeyboard.layouts;

import android.content.Context;
import android.content.res.AssetManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class LayoutManager {
    private Context ctx;
    private List<KeyboardLayout> layouts = new ArrayList<>();

    public LayoutManager(Context c) {
        ctx = c;
        loadDefaults();
        loadFromStorage();
    }

    private void loadDefaults() {
        try {
            AssetManager am = ctx.getAssets();
            InputStream is = am.open("sample_qwerty.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");
            layouts.add(KeyboardLayout.fromJson(json));
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void loadFromStorage() {
        // TODO: scan ctx.getFilesDir() for additional .json layout files
    }

    public KeyboardLayout getDefaultLayout() {
        return layouts.get(0);
    }

    public List<KeyboardLayout> getAllLayouts() { return layouts; }
}
