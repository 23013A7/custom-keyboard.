package com.example.customkeyboard.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.example.customkeyboard.layouts.KeyboardLayout;
import java.util.List;

public class DynamicKeyboardView extends FrameLayout {
    private KeyboardLayout current;
    private KeyPressListener listener;

    private boolean isFloating = false;
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;

    public interface KeyPressListener { void onKeyPressed(String key); }

    public DynamicKeyboardView(Context c, AttributeSet a) { super(c, a); init(); }
    public DynamicKeyboardView(Context c) { super(c); init(); }

    private void init() {
        windowManager = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
    }

    public void setKeyPressListener(KeyPressListener l) { listener = l; }

    public void bindLayout(KeyboardLayout layout) {
        current = layout;
        removeAllViews();
        for (List<String> row : current.rows) {
            FrameLayout rowLayout = new FrameLayout(getContext());
            rowLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            int idx=0;
            for (String key : row) {
                TextView tv = new TextView(getContext());
                tv.setText(key);
                tv.setTextSize(18);
                tv.setPadding(18,18,18,18);
                LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                lp.leftMargin = idx * 120;
                tv.setLayoutParams(lp);
                final String k = key;
                tv.setOnClickListener(v -> { if (listener!=null) listener.onKeyPressed(k); });
                rowLayout.addView(tv);
                idx++;
            }
            addView(rowLayout);
        }
    }

    public void showAsFloating() {
        if (isFloating) return;
        isFloating = true;
        floatingView = this;
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0; params.y = 100;
        windowManager.addView(floatingView, params);

        floatingView.setOnTouchListener(new OnTouchListener() {
            private int startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = (int) event.getRawX();
                        startY = (int) event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) event.getRawX() - startX;
                        int dy = (int) event.getRawY() - startY;
                        params.x += dx; params.y += dy;
                        windowManager.updateViewLayout(floatingView, params);
                        startX = (int) event.getRawX();
                        startY = (int) event.getRawY();
                        return true;
                }
                return false;
            }
        });
    }

    public void hideFloating() {
        if (!isFloating) return;
        windowManager.removeView(floatingView);
        isFloating = false;
        floatingView = null;
    }
}
